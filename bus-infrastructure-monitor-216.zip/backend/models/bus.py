from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


BusStatus = Literal["active", "inactive", "maintenance"]


class BusCreate(BaseModel):
    bus_number: str = Field(min_length=1, max_length=100)
    route_number: str = Field(min_length=1, max_length=100)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    status: BusStatus = "active"


class BusResponse(BusCreate):
    model_config = ConfigDict(from_attributes=True)

    id: str
    last_updated: datetime


class BusLocationUpdate(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    timestamp: datetime


class BusLocationResponse(BaseModel):
    bus_id: str
    latitude: float
    longitude: float
    timestamp: datetime
