from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


DetectionSeverity = Literal["low", "medium", "high", "critical"]
DetectionStatus = Literal["new", "reviewed", "resolved"]


class DetectionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    bus_id: str
    detection_type: str
    confidence: float = Field(ge=0, le=1)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    severity: DetectionSeverity
    image_url: str | None = None
    detected_at: datetime
    status: DetectionStatus


class DetectionStatusUpdate(BaseModel):
    status: DetectionStatus


class AnalysisResponse(BaseModel):
    bus_id: str
    image_url: str | None
    processed_at: datetime
    detection_count: int
    detections: list[DetectionResponse]
