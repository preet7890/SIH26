# SIH26124 Backend API

FastAPI backend for SIH 2026 Problem Statement SIH26124. Public buses provide GPS coordinates and camera images; YOLO detections are geo-tagged and persisted in Supabase PostgreSQL.

This directory is intentionally independent of the React/Agent-Native frontend. The frontend can call these REST endpoints from a separately deployed application.

## Setup

1. Create a Python 3.11+ virtual environment.
2. Install dependencies:

   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r backend/requirements.txt
   ```

3. Copy `backend/.env.example` to `backend/.env` and set real values. Never commit the service key.
4. Run `backend/schema.sql` in the Supabase SQL editor.
5. Create a Supabase Storage bucket named by `SUPABASE_STORAGE_BUCKET`. The current implementation returns public object URLs, so the bucket must be public for those URLs to resolve. For private buckets, switch the storage service to signed URLs before production.
6. Place the YOLO model at `YOLO_MODEL_PATH` or use the default `yolov8n.pt` model name.

Start the server from the repository root:

```bash
uvicorn backend.main:app --reload
```

OpenAPI documentation is available at `/docs` when the server is running.

## Environment variables

- `SUPABASE_URL`: Supabase project URL.
- `SUPABASE_SERVICE_KEY`: server-only Supabase service-role key.
- `SUPABASE_STORAGE_BUCKET`: bucket used for analyzed images.
- `YOLO_MODEL_PATH`: local path or supported model name for Ultralytics YOLO.
- `CORS_ORIGINS`: comma-separated frontend origins.
- `MAX_IMAGE_SIZE_BYTES`: upload limit; defaults to 10 MiB.

## REST API

### Health

- `GET /api/health` checks required configuration and the Supabase connection.

### Buses

- `POST /api/buses` registers a bus.
- `GET /api/buses` returns all buses.
- `GET /api/buses/{bus_id}` returns one bus.
- `PUT /api/buses/{bus_id}/location` updates latitude, longitude, and timestamp.
- `GET /api/buses/{bus_id}/location` returns the latest location stored for the bus.

Register a bus:

```json
{
  "bus_number": "BUS-001",
  "route_number": "R-12",
  "latitude": 28.6139,
  "longitude": 77.2090,
  "status": "active"
}
```

Update location:

```json
{
  "latitude": 28.6141,
  "longitude": 77.2094,
  "timestamp": "2026-01-15T10:30:00Z"
}
```

### Image analysis

`POST /api/analyze-image` accepts `multipart/form-data`:

- `image`: JPEG, PNG, or WebP file.
- `bus_id`: registered bus id.
- `latitude` and `longitude`: optional override; if omitted, the bus's latest stored location is used.
- `confidence_threshold`: optional YOLO threshold from `0.01` to `1.0`, default `0.25`.
- `detected_at`: optional ISO timestamp; defaults to processing time.

Each YOLO detection is stored with its bus coordinates, confidence, severity, image URL, timestamp, and `new` status. If YOLO finds no detections, the API returns an empty detection list and does not upload an unused image.

### Detections

- `GET /api/detections` lists detections. Optional query parameters: `bus_id`, `status`, `detection_type`, `limit`, and `offset`.
- `GET /api/detections/{detection_id}` returns one detection.
- `PUT /api/detections/{detection_id}/status` changes status to `new`, `reviewed`, or `resolved`.

## Production notes

The service key is used only on the backend and must never be exposed to the frontend. Add authentication, rate limiting, private storage signed URLs, and a production model-serving strategy before exposing the API publicly.
