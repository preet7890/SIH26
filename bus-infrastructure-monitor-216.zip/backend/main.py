from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api.routes_analysis import router as analysis_router
from .api.routes_buses import router as buses_router
from .api.routes_detections import router as detections_router
from .api.routes_health import router as health_router
from .utils.helpers import get_cors_origins


load_dotenv(Path(__file__).with_name(".env"))


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield


app = FastAPI(
    title="SIH26124 Urban Infrastructure Monitoring API",
    description="Backend APIs for bus-based infrastructure and traffic monitoring.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=get_cors_origins(),
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(health_router)
app.include_router(buses_router)
app.include_router(detections_router)
app.include_router(analysis_router)
