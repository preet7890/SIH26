from typing import Any


def validate_coordinates(latitude: float, longitude: float) -> tuple[float, float]:
    if not -90 <= latitude <= 90:
        raise ValueError("latitude must be between -90 and 90")
    if not -180 <= longitude <= 180:
        raise ValueError("longitude must be between -180 and 180")
    return latitude, longitude


def resolve_coordinates(
    bus: dict[str, Any], latitude: float | None, longitude: float | None
) -> tuple[float, float]:
    if (latitude is None) != (longitude is None):
        raise ValueError("latitude and longitude must be provided together")

    resolved_latitude = bus["latitude"] if latitude is None else latitude
    resolved_longitude = bus["longitude"] if longitude is None else longitude
    return validate_coordinates(resolved_latitude, resolved_longitude)
