import cv2
import numpy as np


class ImageDecodeError(ValueError):
    pass


class OpenCVService:
    def decode_image(self, image_bytes: bytes) -> np.ndarray:
        buffer = np.frombuffer(image_bytes, dtype=np.uint8)
        image = cv2.imdecode(buffer, cv2.IMREAD_COLOR)
        if image is None:
            raise ImageDecodeError("The uploaded file is not a readable image")
        return image


opencv_service = OpenCVService()
