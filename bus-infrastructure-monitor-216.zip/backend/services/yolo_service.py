import os
from dataclasses import dataclass
from threading import Lock
from typing import Any

import numpy as np


class YoloUnavailableError(RuntimeError):
    pass


@dataclass(frozen=True)
class YoloDetection:
    detection_type: str
    confidence: float
    bounding_box: list[float]


class YoloService:
    def __init__(self) -> None:
        self._model: Any = None
        self._load_lock = Lock()

    def _get_model(self) -> Any:
        if self._model is not None:
            return self._model

        with self._load_lock:
            if self._model is not None:
                return self._model
            try:
                from ultralytics import YOLO
            except ImportError as exc:
                raise YoloUnavailableError(
                    "YOLO is unavailable. Install backend/requirements.txt."
                ) from exc

            model_path = os.getenv("YOLO_MODEL_PATH", "yolov8n.pt")
            try:
                self._model = YOLO(model_path)
            except Exception as exc:
                raise YoloUnavailableError(
                    f"Unable to load YOLO model from {model_path}"
                ) from exc

        return self._model

    def detect(
        self, image: np.ndarray, confidence_threshold: float
    ) -> list[YoloDetection]:
        model = self._get_model()
        try:
            results = model.predict(
                source=image,
                conf=confidence_threshold,
                verbose=False,
            )
        except Exception as exc:
            raise YoloUnavailableError("YOLO inference failed") from exc

        detections: list[YoloDetection] = []
        for result in results:
            boxes = getattr(result, "boxes", None)
            if boxes is None:
                continue

            names = getattr(result, "names", {})
            for class_id, confidence, coordinates in zip(
                boxes.cls.tolist(),
                boxes.conf.tolist(),
                boxes.xyxy.tolist(),
            ):
                class_id = int(class_id)
                label = names.get(class_id, str(class_id)) if isinstance(names, dict) else str(class_id)
                detections.append(
                    YoloDetection(
                        detection_type=label,
                        confidence=float(confidence),
                        bounding_box=[float(value) for value in coordinates],
                    )
                )

        return detections


yolo_service = YoloService()
