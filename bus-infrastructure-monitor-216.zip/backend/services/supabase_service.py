import os
from functools import lru_cache
from typing import Any

from supabase import Client, create_client

from ..utils.helpers import get_required_env


class SupabaseServiceError(RuntimeError):
    pass


class SupabaseService:
    def __init__(self) -> None:
        self.client: Client = create_client(
            get_required_env("SUPABASE_URL"),
            get_required_env("SUPABASE_SERVICE_KEY"),
        )
        self.bucket = os.getenv("SUPABASE_STORAGE_BUCKET", "bus-detections")

    @staticmethod
    def _data(response: Any) -> list[dict[str, Any]]:
        if getattr(response, "error", None):
            raise SupabaseServiceError(str(response.error))
        return response.data or []

    def list_buses(self) -> list[dict[str, Any]]:
        response = (
            self.client.table("buses")
            .select("*")
            .order("last_updated", desc=True)
            .execute()
        )
        return self._data(response)

    def get_bus(self, bus_id: str) -> dict[str, Any] | None:
        response = (
            self.client.table("buses")
            .select("*")
            .eq("id", bus_id)
            .limit(1)
            .execute()
        )
        rows = self._data(response)
        return rows[0] if rows else None

    def create_bus(self, payload: dict[str, Any]) -> dict[str, Any]:
        response = self.client.table("buses").insert(payload).execute()
        rows = self._data(response)
        if not rows:
            raise SupabaseServiceError("Supabase did not return the created bus")
        return rows[0]

    def update_bus_location(
        self, bus_id: str, latitude: float, longitude: float, timestamp: Any
    ) -> dict[str, Any] | None:
        response = (
            self.client.table("buses")
            .update(
                {
                    "latitude": latitude,
                    "longitude": longitude,
                    "last_updated": timestamp.isoformat(),
                }
            )
            .eq("id", bus_id)
            .execute()
        )
        rows = self._data(response)
        return rows[0] if rows else None

    def list_detections(
        self,
        bus_id: str | None,
        status: str | None,
        detection_type: str | None,
        limit: int,
        offset: int,
    ) -> list[dict[str, Any]]:
        query = (
            self.client.table("detections")
            .select("*")
            .order("detected_at", desc=True)
            .range(offset, offset + limit - 1)
        )
        if bus_id:
            query = query.eq("bus_id", bus_id)
        if status:
            query = query.eq("status", status)
        if detection_type:
            query = query.eq("detection_type", detection_type)
        return self._data(query.execute())

    def get_detection(self, detection_id: str) -> dict[str, Any] | None:
        response = (
            self.client.table("detections")
            .select("*")
            .eq("id", detection_id)
            .limit(1)
            .execute()
        )
        rows = self._data(response)
        return rows[0] if rows else None

    def update_detection_status(
        self, detection_id: str, status: str
    ) -> dict[str, Any] | None:
        response = (
            self.client.table("detections")
            .update({"status": status})
            .eq("id", detection_id)
            .execute()
        )
        rows = self._data(response)
        return rows[0] if rows else None

    def create_detection(self, payload: dict[str, Any]) -> dict[str, Any]:
        response = self.client.table("detections").insert(payload).execute()
        rows = self._data(response)
        if not rows:
            raise SupabaseServiceError("Supabase did not return the created detection")
        return rows[0]

    def upload_image(
        self, storage_path: str, image_bytes: bytes, content_type: str
    ) -> str:
        try:
            self.client.storage.from_(self.bucket).upload(
                storage_path,
                image_bytes,
                {"content-type": content_type, "upsert": "false"},
            )
            return str(self.client.storage.from_(self.bucket).get_public_url(storage_path))
        except Exception as exc:
            raise SupabaseServiceError("Unable to upload image to Supabase Storage") from exc

    def check_connection(self) -> None:
        response = self.client.table("buses").select("id").limit(1).execute()
        self._data(response)


@lru_cache(maxsize=1)
def get_supabase_service() -> SupabaseService:
    return SupabaseService()
