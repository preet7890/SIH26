create extension if not exists pgcrypto;

create table if not exists public.buses (
    id uuid primary key default gen_random_uuid(),
    bus_number text not null unique,
    route_number text not null,
    latitude double precision not null check (latitude between -90 and 90),
    longitude double precision not null check (longitude between -180 and 180),
    status text not null default 'active' check (status in ('active', 'inactive', 'maintenance')),
    last_updated timestamptz not null default now()
);

create table if not exists public.detections (
    id uuid primary key default gen_random_uuid(),
    bus_id uuid not null references public.buses(id) on delete cascade,
    detection_type text not null,
    confidence double precision not null check (confidence between 0 and 1),
    latitude double precision not null check (latitude between -90 and 90),
    longitude double precision not null check (longitude between -180 and 180),
    severity text not null default 'medium' check (severity in ('low', 'medium', 'high', 'critical')),
    image_url text,
    detected_at timestamptz not null default now(),
    status text not null default 'new' check (status in ('new', 'reviewed', 'resolved'))
);

create index if not exists detections_bus_id_idx on public.detections (bus_id);
create index if not exists detections_detected_at_idx on public.detections (detected_at desc);
create index if not exists detections_status_idx on public.detections (status);

-- Create the storage bucket in Supabase Storage with the same name as SUPABASE_STORAGE_BUCKET.
-- Keep the bucket private and replace get_public_url with signed URLs before production if needed.
