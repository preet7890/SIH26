from fastapi import APIRouter, HTTPException, Query, status

from ..models.detection import (
    DetectionResponse,
    DetectionStatus,
    DetectionStatusUpdate,
)
from ..services.supabase_service import SupabaseServiceError, get_supabase_service


router = APIRouter(prefix="/api/detections", tags=["detections"])


def database_unavailable(exc: Exception) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Supabase is unavailable: {exc}",
    )


@router.get("", response_model=list[DetectionResponse])
def list_detections(
    bus_id: str | None = None,
    detection_status: DetectionStatus | None = Query(default=None, alias="status"),
    detection_type: str | None = None,
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
) -> list[DetectionResponse]:
    service = get_supabase_service()
    try:
        detections = service.list_detections(
            bus_id, detection_status, detection_type, limit, offset
        )
        return [DetectionResponse.model_validate(item) for item in detections]
    except SupabaseServiceError as exc:
        raise database_unavailable(exc) from exc


@router.get("/{detection_id}", response_model=DetectionResponse)
def get_detection(detection_id: str) -> DetectionResponse:
    service = get_supabase_service()
    try:
        detection = service.get_detection(detection_id)
    except SupabaseServiceError as exc:
        raise database_unavailable(exc) from exc
    if detection is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Detection not found"
        )
    return DetectionResponse.model_validate(detection)


@router.put("/{detection_id}/status", response_model=DetectionResponse)
def update_detection_status(
    detection_id: str, payload: DetectionStatusUpdate
) -> DetectionResponse:
    service = get_supabase_service()
    try:
        detection = service.update_detection_status(detection_id, payload.status)
    except SupabaseServiceError as exc:
        raise database_unavailable(exc) from exc
    if detection is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Detection not found"
        )
    return DetectionResponse.model_validate(detection)
