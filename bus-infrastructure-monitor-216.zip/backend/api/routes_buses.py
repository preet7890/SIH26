from fastapi import APIRouter, HTTPException, status

from ..models.bus import (
    BusCreate,
    BusLocationResponse,
    BusLocationUpdate,
    BusResponse,
)
from ..services.supabase_service import (
    SupabaseServiceError,
    get_supabase_service,
)
from ..utils.helpers import utc_now
from ..services.gps_service import validate_coordinates


router = APIRouter(prefix="/api/buses", tags=["buses"])


def database_unavailable(exc: Exception) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Supabase is unavailable: {exc}",
    )


@router.post("", response_model=BusResponse, status_code=status.HTTP_201_CREATED)
def register_bus(payload: BusCreate) -> BusResponse:
    service = get_supabase_service()
    try:
        bus = service.create_bus(
            {
                **payload.model_dump(),
                "last_updated": utc_now().isoformat(),
            }
        )
        return BusResponse.model_validate(bus)
    except SupabaseServiceError as exc:
        raise database_unavailable(exc) from exc


@router.get("", response_model=list[BusResponse])
def list_buses() -> list[BusResponse]:
    service = get_supabase_service()
    try:
        return [BusResponse.model_validate(bus) for bus in service.list_buses()]
    except SupabaseServiceError as exc:
        raise database_unavailable(exc) from exc


@router.get("/{bus_id}", response_model=BusResponse)
def get_bus(bus_id: str) -> BusResponse:
    service = get_supabase_service()
    try:
        bus = service.get_bus(bus_id)
    except SupabaseServiceError as exc:
        raise database_unavailable(exc) from exc
    if bus is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bus not found")
    return BusResponse.model_validate(bus)


@router.put("/{bus_id}/location", response_model=BusLocationResponse)
def update_location(bus_id: str, payload: BusLocationUpdate) -> BusLocationResponse:
    validate_coordinates(payload.latitude, payload.longitude)
    service = get_supabase_service()
    try:
        bus = service.update_bus_location(
            bus_id, payload.latitude, payload.longitude, payload.timestamp
        )
    except SupabaseServiceError as exc:
        raise database_unavailable(exc) from exc
    if bus is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bus not found")
    return BusLocationResponse(
        bus_id=str(bus["id"]),
        latitude=bus["latitude"],
        longitude=bus["longitude"],
        timestamp=bus["last_updated"],
    )


@router.get("/{bus_id}/location", response_model=BusLocationResponse)
def get_location(bus_id: str) -> BusLocationResponse:
    service = get_supabase_service()
    try:
        bus = service.get_bus(bus_id)
    except SupabaseServiceError as exc:
        raise database_unavailable(exc) from exc
    if bus is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bus not found")
    return BusLocationResponse(
        bus_id=str(bus["id"]),
        latitude=bus["latitude"],
        longitude=bus["longitude"],
        timestamp=bus["last_updated"],
    )
