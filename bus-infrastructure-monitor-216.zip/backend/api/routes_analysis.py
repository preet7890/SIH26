from datetime import datetime

from fastapi import APIRouter, File, Form, HTTPException, UploadFile, status

from ..models.detection import AnalysisResponse, DetectionResponse
from ..services.gps_service import resolve_coordinates
from ..services.opencv_service import ImageDecodeError, opencv_service
from ..services.supabase_service import SupabaseServiceError, get_supabase_service
from ..services.yolo_service import YoloUnavailableError, yolo_service
from ..utils.helpers import (
    detection_severity,
    get_max_image_size,
    image_extension,
    storage_path,
    utc_now,
)


router = APIRouter(prefix="/api", tags=["analysis"])


@router.post("/analyze-image", response_model=AnalysisResponse)
async def analyze_image(
    image: UploadFile = File(...),
    bus_id: str = Form(...),
    latitude: float | None = Form(default=None, ge=-90, le=90),
    longitude: float | None = Form(default=None, ge=-180, le=180),
    confidence_threshold: float = Form(default=0.25, ge=0.01, le=1.0),
    detected_at: datetime | None = Form(default=None),
) -> AnalysisResponse:
    if image.content_type not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail="Only JPEG, PNG, and WebP images are supported",
        )

    max_image_size = get_max_image_size()
    image_parts: list[bytes] = []
    image_size = 0
    while chunk := await image.read(1024 * 1024):
        image_size += len(chunk)
        if image_size > max_image_size:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail="The uploaded image exceeds the configured size limit",
            )
        image_parts.append(chunk)

    image_bytes = b"".join(image_parts)
    if not image_bytes:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The uploaded image is empty",
        )

    service = get_supabase_service()
    try:
        bus = service.get_bus(bus_id)
        if bus is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Bus not found"
            )

        resolved_latitude, resolved_longitude = resolve_coordinates(
            bus, latitude, longitude
        )
        decoded_image = opencv_service.decode_image(image_bytes)
        detections = yolo_service.detect(decoded_image, confidence_threshold)
        processed_at = utc_now()

        image_url: str | None = None
        if detections:
            extension = image_extension(image.content_type, image.filename)
            image_url = service.upload_image(
                storage_path(bus_id, extension), image_bytes, image.content_type
            )

        persisted_detections: list[DetectionResponse] = []
        for detection in detections:
            record = service.create_detection(
                {
                    "bus_id": bus_id,
                    "detection_type": detection.detection_type,
                    "confidence": detection.confidence,
                    "latitude": resolved_latitude,
                    "longitude": resolved_longitude,
                    "severity": detection_severity(detection.confidence),
                    "image_url": image_url,
                    "detected_at": (detected_at or processed_at).isoformat(),
                    "status": "new",
                }
            )
            persisted_detections.append(DetectionResponse.model_validate(record))

        return AnalysisResponse(
            bus_id=bus_id,
            image_url=image_url,
            processed_at=processed_at,
            detection_count=len(persisted_detections),
            detections=persisted_detections,
        )
    except HTTPException:
        raise
    except ImageDecodeError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except YoloUnavailableError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)
        ) from exc
    except SupabaseServiceError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Supabase is unavailable: {exc}",
        ) from exc
