from fastapi import APIRouter, HTTPException, status

from ..services.supabase_service import SupabaseServiceError, get_supabase_service
from ..utils.helpers import get_required_env, utc_now


router = APIRouter(prefix="/api", tags=["health"])


@router.get("/health")
def health_check() -> dict[str, str]:
    try:
        get_required_env("SUPABASE_URL")
        get_required_env("SUPABASE_SERVICE_KEY")
        get_supabase_service().check_connection()
    except (RuntimeError, SupabaseServiceError) as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Backend is not ready: {exc}",
        ) from exc

    return {"status": "ok", "timestamp": utc_now().isoformat()}
