import os
import re
from datetime import datetime, timezone
from uuid import uuid4


ALLOWED_IMAGE_TYPES = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def get_required_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def get_cors_origins() -> list[str]:
    configured = os.getenv("CORS_ORIGINS", "*")
    return [origin.strip() for origin in configured.split(",") if origin.strip()]


def get_max_image_size() -> int:
    return int(os.getenv("MAX_IMAGE_SIZE_BYTES", str(10 * 1024 * 1024)))


def image_extension(content_type: str | None, filename: str | None) -> str:
    if content_type in ALLOWED_IMAGE_TYPES:
        return ALLOWED_IMAGE_TYPES[content_type]

    suffix = re.sub(r"[^a-zA-Z0-9.]", "", (filename or "").lower())
    if suffix.endswith((".jpg", ".jpeg")):
        return ".jpg"
    if suffix.endswith((".png", ".webp")):
        return ".webp" if suffix.endswith(".webp") else ".png"
    raise ValueError("Only JPEG, PNG, and WebP images are supported")


def storage_path(bus_id: str, extension: str) -> str:
    return f"{bus_id}/{utc_now().strftime('%Y/%m/%d')}/{uuid4().hex}{extension}"


def detection_severity(confidence: float) -> str:
    if confidence >= 0.9:
        return "high"
    if confidence >= 0.6:
        return "medium"
    return "low"
